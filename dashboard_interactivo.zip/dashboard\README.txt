Dashboard profesional del modelo multivariado del precio del oro

Archivo principal:
index.html

Para abrirlo, haga doble clic sobre index.html desde esta carpeta.

Contenido del tablero:
- Resumen ejecutivo con KPIs principales.
- Navegacion lateral por secciones.
- Serie historica del oro con velas OHLC, medias moviles y volatilidad.
- Distribucion de retornos historicos.
- Comparacion de modelos por RMSE de validacion temporal y test.
- Matriz de metricas por modelo.
- Prediccion real vs predicha en test.
- Diagnostico de errores, dispersion e histograma.
- Composicion de variables usadas por el modelo.
- Importancia LightGBM y SHAP.
- Pronostico mayo, junio y julio de 2026.
- Escenarios Monte Carlo hasta 2035 con bandas P10-P90.
- Resumen ejecutivo de escenarios.
- Trayectoria individual Monte Carlo con choques diarios.
- Enlaces de descarga a PDFs, Excel y CSV.

Nota: el tablero usa Plotly cargado desde CDN. Si el equipo no tiene internet,
algunas graficas interactivas pueden no cargarse correctamente.
